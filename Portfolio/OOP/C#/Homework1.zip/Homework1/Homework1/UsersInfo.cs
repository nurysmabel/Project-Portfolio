﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Homework1
{
    class Class1
    {
    }
}
