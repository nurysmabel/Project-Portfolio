﻿using System;
using System.Runtime.CompilerServices;

namespace Homework1
{
    class Program
    {
        // User Info Variables
        public static string firstName, lastName;
        public static int age;
        public static string gender;
        public static string funds;
        public static float userBalance;

        static void Main(string[] args)
        {
            Console.WriteLine("Homework 1 - Product List \n");
            Console.WriteLine("Welcome to the UwU Shop\r");
            Console.WriteLine("------------------------\n");
            Console.Beep();
            Console.WriteLine("Would you like to create an order? (Type Y for yes, N for no)");
            string firstQuestion = Console.ReadLine();
            if (firstQuestion == "Y" || firstQuestion == "y")
            {
                Console.WriteLine("We require you to enter you personal details to create an order. Please follow the instructions provided");
                Console.WriteLine("---------------------------------------------------------------------------------------------------------\n");
                UserInfo();
            }
            else
            {
                Console.WriteLine("Are you sure you do not want to make a order? (Type Y for yes, N for No)");
                string secondQuestion = Console.ReadLine();
                if (secondQuestion == "Y")
                {
                    Console.WriteLine("Please Press any key to close this application");
                    Console.ReadKey();
                    Environment.Exit(0);
                } else
                {
                    Console.Write("Redirecting to User Application... \n");
                    UserInfo();
                }
            }
        }

        static void UserInfo()
        {
            Console.WriteLine("Please type in your FIRST NAME and press enter");
            firstName = Console.ReadLine();
            Console.WriteLine("Please type your LAST NAME and press enter ");
            lastName = Console.ReadLine();
            Console.WriteLine("Please type your AGE in years and press enter");
            age = Convert.ToInt32(Console.ReadLine());
            if (age < 18)
            {
                Console.WriteLine("We are sorry, but you are too young to make authorized purchases from this application.\n Please press any key to close this application");
                Console.ReadKey();
                Environment.Exit(0);
            }
            Console.WriteLine("Please type your gender H for male, and M for female then press enter");
            gender = Console.ReadLine();
            if (gender == "H" || gender == "h")
            {
                gender = "Male";
            }
            else if (gender == "M" || gender == "m")
            {
                gender = "Female";
            } else
            {
                Console.WriteLine("Incrorect information typed in, please try again.");
                UserInfo();
            }
            Console.WriteLine("Please type in your ammount of money you pocess and press enter");
            funds = Console.ReadLine();
            userBalance = float.Parse(funds);
            Console.WriteLine("Thank you for entering this personal information in.");
            Console.WriteLine("Just to confirm this data entered is correct");
            Console.WriteLine(" Your name is {0} {1}, you are {2} and {3} years old. Your current balance of this account is ${4}\n", firstName, lastName, gender, age, userBalance);
            Console.WriteLine("If this is correct type Y for yes, N for No.");
            string confirmationQuestion = Console.ReadLine();
            if (confirmationQuestion == "N" || confirmationQuestion == "n")
            {
                Console.WriteLine("We are sorry this information is incorrect, please try again");
                UserInfo();
            }
            Console.WriteLine("Would you like to view the catalogue now? Type Y for yes, N for no");
            string confirmationQuestion1 = Console.ReadLine();
            if (confirmationQuestion1 == "Y" || confirmationQuestion1 == "y")
            {
                Catalogue();
            }
            else
            {
                Console.WriteLine("Why did you bother filling out this form then you silly goose. Press any key to honk and close the application");
                Console.Beep();
                Console.ReadKey();
                Environment.Exit(0);
            }

        }
        static void Catalogue()
        {

            // GST
            double gst = 0.05;

            // Order
            float order1Cost = 0;
            float order2Cost = 0;
            float order3Cost = 0;
            float order4Cost = 0;
            float orderTotal = 0;

            // UwU Pantsu
            int pantsuID = 1;
            string parasolName = "UwU Parasol";
            double parasolCost = 19.99;

            // UwU Onsie
            int onsieID = 2;
            string hatName = "UwU Neko Hat";
            double hatCost = 59.99;

            // UwU Mug
            int mugID = 3;
            string mugName = "UwU Neko Mug";
            double mugCost = 9.99;

            // Uwu Hoody
            int hoodyID = 4;
            string hoodyName = "UwU Kawaii Hoody";
            double hoodyCost = 49.99;

            Console.WriteLine("Avalaible Products");
            Console.WriteLine("------------------------------------------------------------\n");
            Console.WriteLine("ID:1 - Name:UwU Parasol - Price:$19.99");
            Console.WriteLine("ID:2 - Name:UwU Neko Hat - Price:$59.99");
            Console.WriteLine("ID:3 - Name:UwU Neko Mug - Price:$9.99");
            Console.WriteLine("ID:4 - Name:UwU Kawaii Hoody - Price:$49.99");
            Console.WriteLine("-------------------------------------------------------------\n");
            Console.WriteLine("Please enter the ID of the item you'd like to purchase then press enter");
            int purchaseid1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("How many would you like to purchase?");
            int purchase1quantity = Convert.ToInt32(Console.ReadLine());
            if (purchaseid1 == 1)
            {
                float parasolCost1 = Convert.ToSingle(parasolCost);
                order1Cost = purchase1quantity * parasolCost1;
                Console.WriteLine("You have selected to purchase {0} x {1} for a total of ${2}\n", purchase1quantity, parasolName, order1Cost);
            }
            else if (purchaseid1 == 2)
            {
                float hatCost1 = Convert.ToSingle(hatCost);
                order1Cost = purchase1quantity * hatCost1;
                Console.WriteLine("You have selected to purchase {0} x {1} for a total of ${2}\n", purchase1quantity, hatName, order1Cost);

            }
            else if (purchaseid1 == 3)
            {
                float mugCost1 = Convert.ToSingle(mugCost);
                order1Cost = purchase1quantity * mugCost1;
                Console.WriteLine("You have selected to purchase {0} x {1} for a total of ${2}\n", purchase1quantity, mugName, order1Cost);
            }
            else if (purchaseid1 == 4)
            {
                float hoodyCost1 = Convert.ToSingle(hoodyCost);
                order1Cost = purchase1quantity * hoodyCost1;
                Console.WriteLine("You have selected to purchase {0} x {1} for a total of ${2}\n", purchase1quantity, hoodyName, order1Cost);
            }

            Console.WriteLine("Would you like to make another order? Type Y for yes and N for no");
            string orderQuestion1 = Console.ReadLine();
            if (orderQuestion1 == "Y" || orderQuestion1 == "y")
            {
                // Second Order
                Console.WriteLine("------------------------------------------------------------\n");
                Console.WriteLine("ID:1 - Name:UwU Neko Onsie - Price:$59.99");
                Console.WriteLine("ID:2 - Name:UwU Neko Mug - Price:$9.99");
                Console.WriteLine("ID:3 - Name:UwU Kawaii Hoody - Price:$49.99");
                Console.WriteLine("-------------------------------------------------------------\n");
                Console.WriteLine("Please enter the second item id you'd like to order");
                int purchaseid2 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("How many would you like to purchase");
                int purchasequantity2 = Convert.ToInt32(Console.ReadLine());
                if (purchaseid2 == 1)
                {
                    float hatcost1 = Convert.ToSingle(hatCost);
                    order2Cost = purchasequantity2 * hatcost1;
                    Console.WriteLine("You have seleceted to purchase {0} x {1} for a total of ${2}\n", purchasequantity2, hatName, order2Cost);
                }
                else if (purchaseid2 == 2)
                {
                    float mugcost2 = Convert.ToSingle(mugCost);
                    order2Cost = purchasequantity2 * mugcost2;
                    Console.WriteLine("You have selected to pruchase {0} x {1} for a total of ${2}\n", purchasequantity2, mugName, order2Cost);
                }
                else if (purchaseid2 == 3)
                {
                    float hoodycost2 = Convert.ToSingle(hoodyCost);
                    order2Cost = purchasequantity2 * hoodycost2;
                    Console.WriteLine("You have selected to purchase {0} x {1} for a total of ${2}\n", purchasequantity2, hoodyName, order2Cost);
                }
                Console.WriteLine("Would you like to make another order? Type Y for yes and N for no");
                string orderQuestion2 = Console.ReadLine();
                if (orderQuestion2 == "Y" || orderQuestion2 == "y")
                {
                    // THIRD ORDER
                    Console.WriteLine("------------------------------------------------------------\n");
                    Console.WriteLine("ID:1 - Name:UwU Neko Mug - Price:$9.99");
                    Console.WriteLine("ID:2 - Name:UwU Kawaii Hoody - Price:$49.99");
                    Console.WriteLine("-------------------------------------------------------------\n");
                    Console.WriteLine("Please enter the third item id you'd like to order");
                    int purchaseid3 = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("How many would you like to purchase?");
                    int purchasequantity3 = Convert.ToInt32(Console.ReadLine());
                    if (purchaseid3 == 1)
                    {
                        float mugcost3 = Convert.ToSingle(mugCost);
                        order3Cost = purchasequantity3 * mugcost3;
                        Console.WriteLine("You have selected to purchase {0} x {1} for a total of ${2}\n", purchasequantity3, mugName, order3Cost);

                    }
                    else if (purchaseid3 == 2)
                    {
                        float hoodycost3 = Convert.ToSingle(hoodyCost);
                        order3Cost = purchasequantity3 * hoodycost3;
                        Console.WriteLine("You have selected to purchase {0} x {1} for a total of ${2}\n", purchasequantity3, hoodyName, order3Cost);
                    }
                    Console.WriteLine("Would you like to make another order? Type Y for yes and N for no");
                    string orderQuestion3 = Console.ReadLine();
                    if (orderQuestion3 == "Y" || orderQuestion3 == "y")
                    {

                        //FOURTH ORDER
                        Console.WriteLine("------------------------------------------------------------\n");
                        Console.WriteLine("ID:1 - Name:UwU Kawaii Hoody - Price:$49.99");
                        Console.WriteLine("-------------------------------------------------------------\n");
                        Console.WriteLine("Please enter the fourth item you'd like to order");
                        int purchaseid4 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("How many would you like to purchase?");
                        int purchasequantity4 = Convert.ToInt32(Console.ReadLine());
                        float hoodycost4 = Convert.ToSingle(hoodyCost);
                        order4Cost = purchasequantity4 * hoodycost4;
                        Console.WriteLine("You have selected to purchase {0} x {1} for a total of ${2}\n", purchasequantity4, hoodyName, order4Cost);
                        Console.WriteLine("Please confrim this order by typing Y for yes, or close this order by typing N for no");
                        string confirm4 = Console.ReadLine();
                        if (confirm4 == "Y" || confirm4 == "y")
                        {
                            if (orderTotal > userBalance)
                            {
                                Console.WriteLine("The Customer does not have enough money to buy the order because it gives a total of ${0}, and customer only has ${1}\n", orderTotal, userBalance);
                                Console.ReadKey();
                            }
                            else if (orderTotal < userBalance)
                            {
                                userBalance = userBalance - orderTotal;
                                Console.WriteLine("Your order was processed, your cost was {0} and was subtracted from your balance.\n Your remaining Balance is {1}\n", orderTotal, userBalance);
                                Console.ReadKey();
                            }

                        }
                        else if (confirm4 == "N" || confirm4 == "n")
                        {
                            Console.WriteLine("You order has been canceld. Please press any key to close this application");
                            Console.ReadKey();
                            Environment.Exit(0);
                        }


                    }
                    else if (orderQuestion3 == "N" || orderQuestion3 == "n")
                    {
                        orderTotal = order1Cost + order2Cost + order3Cost + order4Cost;
                        float gst3 = Convert.ToSingle(gst);
                        float gstcost3 = orderTotal * gst3;
                        orderTotal = orderTotal + gstcost3;
                        Console.WriteLine("The total cost of your order it {0}\n", orderTotal);
                        Console.WriteLine("Please confirm this order by typing Y for yes, or close this order by typing N for no");
                        string confirm3 = Console.ReadLine();
                        if (confirm3 == "Y" || confirm3 == "y")
                        {
                            if (orderTotal > userBalance)
                            {
                                Console.WriteLine("The Customer does not have enough money to buy the order because it gives a total of ${0}, and customer only has ${1}\n", orderTotal, userBalance);
                                Console.ReadKey();
                            }
                            else if (orderTotal < userBalance)
                            {
                                userBalance = userBalance - orderTotal;
                                Console.WriteLine("Your order was processed, your cost was {0} and was subtracted from your balance. Your remaining Balance is {1}\n", orderTotal, userBalance);
                                Console.ReadKey();
                            }

                        }
                        else if (confirm3 == "N" || confirm3 == "n")
                        {
                            Console.WriteLine("You order has been canceld. Please press any key to close this application");
                            Console.ReadKey();
                            Environment.Exit(0);
                        }

                    }

                }
                else if (orderQuestion2 == "N" || orderQuestion2 == "n")
                {
                    orderTotal = order1Cost + order2Cost + order3Cost + order4Cost;
                    float gst2 = Convert.ToSingle(gst);
                    float gstcost2 = orderTotal * gst2;
                    orderTotal = orderTotal + gstcost2;
                    Console.WriteLine("The total cost of your order is {0}\n", orderTotal);
                    Console.WriteLine("Please confirm this order by typing Y for yes, or close this order by typing N for no");
                    string confirm2 = Console.ReadLine();
                    if (confirm2 == "Y" || confirm2 == "y")
                    {
                        if (orderTotal > userBalance)
                        {
                            Console.WriteLine("The Customer does not have enough money to buy the order because it gives a total of ${0}, and customer only has ${1}\n", orderTotal, userBalance);
                            Console.ReadKey();
                        }
                        else if (orderTotal < userBalance)
                        {
                            userBalance = userBalance - orderTotal;
                            Console.WriteLine("Your order was processed, your cost was {0} and was subtracted from your balance. Your remaining Balance is {1}\n", orderTotal, userBalance);
                            Console.ReadKey();
                        }

                    }
                    else if (confirm2 == "N" || confirm2 == "n")
                    {
                        Console.WriteLine("You order has been canceld. Please press any key to close this application");
                        Console.ReadKey();
                        Environment.Exit(0);
                    }
                }
            }

            // Only 1 order
            else if (orderQuestion1 == "N" || orderQuestion1 == "n")
            {
                orderTotal = order1Cost + order2Cost + order3Cost + order4Cost;
                float gst1 = Convert.ToSingle(gst);
                float gstcost = orderTotal * gst1;
                orderTotal = orderTotal + gstcost;
                Console.WriteLine("The total cost of your order is ${0} \n", orderTotal);
                Console.WriteLine("Please Confirm this order by typing Y for yes, or close this order by typing N for no");
                string confirm1 = Console.ReadLine();
                if (confirm1 == "Y" || confirm1 == "y")
                {
                    if (orderTotal > userBalance)
                    {
                        Console.WriteLine("The Customer does not have enough money to buy the order because it gives a total of ${0}, and customer only has ${1}\n", orderTotal, userBalance);
                        Console.ReadKey();
                    }
                    else if (orderTotal < userBalance)
                    {
                        userBalance = userBalance - orderTotal;
                        Console.WriteLine("Your order was processed, your cost was {0} and was subtracted from your balance. Your remaining Balance is {1}\n", orderTotal, userBalance);
                        Console.ReadKey();
                    }

                }
                else if (confirm1 == "N" || confirm1 == "n")
                {
                    Console.WriteLine("You order has been canceld. Please press any key to close this application");
                    Console.ReadKey();
                }
            }
        }
    }
}
