﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ElevatorPP
{
        public class persona
    {
            public String Nombre, Apellido, Genero;
            public float Peso;

        }
    }

