﻿using System;

namespace ElevatorPP
{
    class Program 
    {
        static void Main(string[] args)
        {
            ascensor elevador = new ascensor();
            Console.WriteLine("Elevator Starting...........................\n");
            System.Threading.Thread.Sleep(1000);
            Console.WriteLine("Scale... OK!\n");
            System.Threading.Thread.Sleep(1000);
            Console.WriteLine("Emercengy Protocol... OK!\n");
            System.Threading.Thread.Sleep(1000);
            Console.WriteLine("Systems... OK!\n");
            System.Threading.Thread.Sleep(500);

            Console.WriteLine("Please, input elevator's weight limit:");
            elevador.PesoLimite = float.Parse (Console.ReadLine());
            Console.WriteLine("Peso Limite: \n" + elevador.PesoLimite);
            System.Threading.Thread.Sleep(1000);
            Console.WriteLine("Recieved...");
            Console.WriteLine("\n");
            System.Threading.Thread.Sleep(1000);

            Console.WriteLine("Redirecting to Person input...");
            System.Threading.Thread.Sleep(1000);    
            Console.Clear();

            persona per = new persona();

            while(elevador.Can_PesoActual() <= elevador.Can_PesoLimite()) 
            { 
                if(elevador.Can_PesoActual() <= elevador.Can_PesoLimite())
                {
                    Console.WriteLine("Input person information\n");
                    Console.WriteLine("Input person name:");
                    per.Nombre = Console.ReadLine();
                    Console.WriteLine("\n");

                    Console.WriteLine("Input person last name:");
                    per.Apellido = Console.ReadLine();
                    Console.WriteLine("\n");

                    Console.WriteLine("Please person gender H for Hombre, and M for Mujer");
                    per.Genero = Console.ReadLine();
                    if (per.Genero == "H" || per.Genero == "h")
                    {
                        per.Genero = "Hombre";
                    }
                    else if (per.Genero == "M" || per.Genero == "m")
                    {
                        per.Genero = "Mujer";
                    }
                    Console.WriteLine("\n");

                    Console.WriteLine("Input person weight:");
                    per.Peso = float.Parse(Console.ReadLine());
                    Console.Clear();

                    elevador.SumarPeso(per.Peso, per.Genero);
                }
            }

                    elevador.RestarPeso(per.Peso, per.Genero);

            Console.WriteLine("Person Elevator Total: ");
            Console.WriteLine("");
            Console.WriteLine("Hombres: " + elevador.Can_CantidadHombre() );
            Console.WriteLine("Mujeres: " + elevador.Can_CantidadMujer());
            Console.WriteLine("Total: " + elevador.Can_TotalCantidad());
            Console.WriteLine("");
            Console.WriteLine("Weight by Gender: ");
            Console.WriteLine("");
            Console.WriteLine("Hombres: " + elevador.Can_PesoHombre());
            Console.WriteLine("Mujeres: " + elevador.Can_PesoMujer());
            Console.WriteLine("Total: " + elevador.Can_TotalPeso());


            Console.ReadKey();
        }
    }
}
