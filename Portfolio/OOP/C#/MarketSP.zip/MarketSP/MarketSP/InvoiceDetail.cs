﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MarketSP
{
    class InvoiceDetail
    {
        public Product Product { get; set; }
        public double Quantity { get; set; }

       
    }
}
