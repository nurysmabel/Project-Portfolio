﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace MarketSP
{
    class Invoice
    {

        public int ID { get; set; }
        public string CustomerName { get; set; }
        public char CustomerGender { get; set; }
        public string CreationDate { get; set; }
        public List<InvoiceDetail> InvoiceDetails { get; set; }

        public static int LastId { get; set; }

        public Invoice()
        {
            InvoiceDetails = new List<InvoiceDetail>();
        }

        public double getTotal(char gender)
        {
            double result = 0.00;
            foreach (InvoiceDetail detail in this.InvoiceDetails)
            {
                result = (result) + (detail.Product.getTotal() * detail.Quantity);
            }

            return result;

        }

        public double getTotalTax(char gender)
        {
            double result = 0.00;
            foreach (InvoiceDetail detail in this.InvoiceDetails)
            {
                result = (result) + (detail.Product.Price + detail.Product.getTax()) * detail.Quantity;
            }

            return result;
        }

        public double getbeforeTax(char gender)
        {
            double result = 0.00;
            foreach (InvoiceDetail detail in this.InvoiceDetails)
            {
                result = (result) + (detail.Product.Price * detail.Quantity);
            }

            return result;
        }
        public void printInvoice()
        {
            Console.WriteLine("Your Invoice");
            Console.WriteLine("\n");
            Console.WriteLine("Invoice ID." + ID + "\n" + "----------Customer Information----------" + "\n" + "Customer Name: "
                              + CustomerName + "    " + "Gender: " + CustomerGender + "\t");
            Console.WriteLine("\n");
            Console.WriteLine("----------Product Information----------\t");

            foreach (InvoiceDetail detail in this.InvoiceDetails)
            {
                Console.WriteLine("Product name: " + detail.Product.name + "    RD$" + detail.Product.Price
                                    + "    Quantity: " + detail.Quantity + "    " + detail.Product.category);
                Console.WriteLine("\n");


                Console.WriteLine("Before Tax: " + getbeforeTax('A'));
                Console.WriteLine("Total: " + getTotalTax('A'));
                Console.WriteLine("");

                DateTime localDate = DateTime.Now;
                DateTime utcDate = DateTime.UtcNow;
                String[] cultureNames = { "en-US" };

                foreach (var cultureName in cultureNames)
                {
                    var culture = new CultureInfo(cultureName);
                    Console.WriteLine("{0}:", culture.NativeName);
                    Console.WriteLine("  Date: {0}, {1:G}",
                                      localDate.ToString(culture), localDate.Kind);
                }

                Console.ReadLine();
            }
        }
    }
}
