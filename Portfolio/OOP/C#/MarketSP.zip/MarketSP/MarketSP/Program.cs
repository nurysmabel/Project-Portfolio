﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices.WindowsRuntime;

namespace MarketSP
{
    class Program
    {
        static void Main(string[] args)
        {
            bool go = true;
            List<Invoice> invoices = new List<Invoice>();

            while (go)
            {
                Console.Clear();
                Console.WriteLine("Welcome to Shine Market!\n");
                Console.WriteLine("How can we help you today?");
                Console.WriteLine("");

                Console.WriteLine("1. Create Invoice\n" +
                                  "2. Print Invoice\n" +
                                  "3. Invoice Report\n" +
                                  "4. Exit");
                Console.WriteLine("");

                Console.Write("Please pick a number! ^o^/");
                Console.WriteLine("\n");
               int selection= Int32.Parse(Console.ReadLine());
                Console.WriteLine("\n");
                System.Threading.Thread.Sleep(1000);
                Console.WriteLine("\n");

            
                switch (selection)
                {
                    case 1:
                        invoices.Add(Menu2());
                        break;
                    case 2:
                        Menu3(invoices);
                        break;
                    case 3:
                        Menu4(invoices);
                        break;
                    case 4:
                        Console.Clear();
                        Console.WriteLine("Thanks for shopping with us!");
                        Console.WriteLine("Have a nice day! =^o^=");
                        System.Threading.Thread.Sleep(2000);
                        go = false;
                        Environment.Exit(0);
                        break;
                }
                Console.ReadKey();

            }
        }
            //Switch for the menu1.
            
            public static Invoice Menu2()
            {
            Console.Clear();
            Console.WriteLine("Create Invoice\n");
            System.Threading.Thread.Sleep(1000);
            Console.WriteLine("Creating Invoice... Please fill the following info:\n");
            System.Threading.Thread.Sleep(1000);


            Invoice invoice = new Invoice();
            invoice.ID = Invoice.LastId++;

            Console.WriteLine("Please input client's name: ");
            invoice.CustomerName = Console.ReadLine();
            Console.WriteLine("\n");

            Console.WriteLine("Please input client's gender:");
            invoice.CustomerGender = Console.ReadKey().KeyChar;
            Console.WriteLine("\n");

            //Product list
            Console.WriteLine("Perfecto! Loading Product List...");
            Console.WriteLine("...");
            System.Threading.Thread.Sleep(1000);
            Console.Clear();

            Console.WriteLine("Product List");
            List<Product> productsCatalog = new List<Product>();
            productsCatalog.Add(new Product(1, "Nesquik", 100.00, "ITBIS"));
            productsCatalog.Add(new Product(2, "Zucaritas", 115.00, "ITBIS"));
            productsCatalog.Add(new Product(3, "Lucky Charms", 130.00, "ITBIS"));
            productsCatalog.Add(new Product(4, "Cinnamon Toasts", 160.00, "ITBIS"));
            Console.WriteLine("\n");

            //Printing Product Catalog
            foreach(Product prod in productsCatalog)
            {
                Console.WriteLine(prod.ID + "." + prod.name + " - " + "RD$" + prod.Price);
            }

            bool go = true;
            while (go)
            {
                Console.WriteLine("\n");
                Console.WriteLine("What would you like to purchase?");
                int selection = Int32.Parse(Console.ReadLine());
                Console.WriteLine("\n");

                InvoiceDetail detail = new InvoiceDetail();

                detail.Product = (productsCatalog[selection - 1]);
                Console.WriteLine("How many " + productsCatalog[selection - 1].name + " would you like?");
                detail.Quantity = (Convert.ToDouble(Console.ReadLine()));
                Console.WriteLine("\n");
                Console.WriteLine("Understood!");

                //Adding item to invoice
                invoice.InvoiceDetails.Add(detail);

                //Keep going?
                Console.WriteLine("Want to add another item? (Y = yes | N = no)");
                if (Console.ReadKey().Key == ConsoleKey.Y)
                {
                    
                    //Go back to product list
                }else{
                    go = false;
                    //Go back to menu1
                }
            }
            return invoice;
        }
        public static void Menu3(List<Invoice> invoices)
        {
            Console.Clear();
            Console.WriteLine("What would you like to do?\n");
            //Printing options
            Console.WriteLine("1. Back");
            for(int i = 1; i <= invoices.Count; i++)
            {
                Console.WriteLine( i+1 + ". Invoice " + i + "\n");
            }
            int selection = Int32.Parse(Console.ReadLine());

            if(selection == 1)
            {

            }
            else
            {
                invoices[selection - 2].printInvoice();
            }
        }

        public static void Menu4(List<Invoice> invoices)
        {
            Console.Clear();
            Console.WriteLine("Please pick an Option\n");

            //Print options
            Console.WriteLine("1. Invoice Report\n" +
                              "2. Invoice Report by Gender\n" +
                              "3. Back");
            Console.WriteLine("Please pick a number");
            Console.WriteLine("\n");

            switch (Int32.Parse(Console.ReadLine()))
            {
                case 1:
                    ReportOne(invoices);
                    break;

                case 2:
                    ReportTwo(invoices);
                    break;

                case 3:
                    //go back to menu1
                    break;
            }
        }

        public static void ReportOne(List<Invoice> invoices)
        {
            Console.WriteLine("Invoice Report");
            Console.WriteLine("\n");
            foreach (Invoice invoice in invoices)
            {
                
                Console.WriteLine("ID." + invoice.ID + "\n" + "Name: " + invoice.CustomerName + " " + "\n" 
                                    + "Gender: " + invoice.CustomerGender + "\n" + "RD$" + invoice.getTotal('M'));
                Console.WriteLine("\n");
            }
        }

        public static void ReportTwo(List<Invoice> invoices)
        {
            double resultM = 0;
            double resultf = 0;
            foreach (Invoice invoice in invoices)
            {
                if (invoice.CustomerGender == 'M')
                {
                    resultM = resultM + invoice.getTotal('M');
                }
                else
                {
                    resultf = resultf + invoice.getTotal('M');
                }
            }
            Console.WriteLine("\n");
            Console.WriteLine("Invoice by Gender");
            Console.WriteLine("Male: " + resultM);
            Console.WriteLine("Female: " + resultf);
            Console.ReadKey();
        }
     }
 }

