﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace MarketSP
{
    class Product
    {
        public int ID;
        public string name;
        public double Price;
        public string category;
 
        public Product(int ID, string name, double Price, string category)
        {
            this.ID = ID;
            this.name = name;
            this.Price = Price;
            this.category = category;
        }

        public double getTax()
        {
            switch (this.category)
            {
                case "ITBIS":
                    return this.Price * 0.18;
                case "STIC":
                case "ICPA":
                    return this.Price * 0.28;
                case "ICPT":
                    return this.Price * 0.38;
                default:
                    return this.Price;
            }

        }

        public double getTotal()
        {
            switch (this.category)
            {
                case "ITBIS":
                    return this.Price * 1.18;
                case "STIC":
                case "ICPA":
                    return this.Price * 1.28;
                case "ICPT":
                    return this.Price * 1.38;
                default:
                    return this.Price;
            }
        }
        
       
    }
}
