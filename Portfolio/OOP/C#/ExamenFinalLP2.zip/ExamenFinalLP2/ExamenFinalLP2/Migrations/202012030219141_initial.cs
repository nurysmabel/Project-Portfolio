﻿namespace ExamenFinalLP2.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class initial : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.CategoriaItebis",
                c => new
                    {
                        CategoriaItebisID = c.Int(nullable: false, identity: true),
                        Nombre = c.String(maxLength: 50, unicode: false),
                        Porcentaje = c.Decimal(nullable: false, precision: 10, scale: 2),
                        Estatus = c.String(maxLength: 100, unicode: false),
                        Borrado = c.Boolean(nullable: false),
                        FechaRegistro = c.DateTime(nullable: false),
                        FechaModificacion = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.CategoriaItebisID);
            
            CreateTable(
                "dbo.Cliente",
                c => new
                    {
                        ClienteID = c.Int(nullable: false, identity: true),
                        Nombre = c.String(maxLength: 100, unicode: false),
                        Apellido = c.String(maxLength: 100, unicode: false),
                        Direccion = c.String(maxLength: 500, unicode: false),
                        Telefono = c.String(maxLength: 15, unicode: false),
                        FechaNacimiento = c.DateTime(nullable: false),
                        Correo = c.String(maxLength: 50, unicode: false),
                        Estatus = c.String(maxLength: 100, unicode: false),
                        Borrado = c.Boolean(nullable: false),
                        FechaRegistro = c.DateTime(nullable: false),
                        FechaModificacion = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ClienteID);
            
            CreateTable(
                "dbo.Factura",
                c => new
                    {
                        FacturaID = c.Int(nullable: false, identity: true),
                        ClienteID = c.Int(nullable: false),
                        MetodoPagoID = c.Int(nullable: false),
                        Estatus = c.String(maxLength: 100, unicode: false),
                        Borrado = c.Boolean(nullable: false),
                        FechaRegistro = c.DateTime(nullable: false),
                        FechaModificacion = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.FacturaID)
                .ForeignKey("dbo.MetodoPago", t => t.MetodoPagoID, cascadeDelete: true)
                .ForeignKey("dbo.Cliente", t => t.ClienteID)
                .Index(t => t.ClienteID)
                .Index(t => t.MetodoPagoID);
            
            CreateTable(
                "dbo.FacturaDetalle",
                c => new
                    {
                        FacturaDetalleID = c.Int(nullable: false, identity: true),
                        FacturaID = c.Int(nullable: false),
                        ProductoID = c.Int(nullable: false),
                        Cantidad = c.Int(nullable: false),
                        Precio = c.Decimal(nullable: false, precision: 10, scale: 2),
                        Estatus = c.String(maxLength: 100, unicode: false),
                        Borrado = c.Boolean(nullable: false),
                        FechaRegistro = c.DateTime(nullable: false),
                        FechaModificacion = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.FacturaDetalleID)
                .ForeignKey("dbo.Factura", t => t.FacturaID)
                .ForeignKey("dbo.Producto", t => t.ProductoID, cascadeDelete: true)
                .Index(t => t.FacturaID)
                .Index(t => t.ProductoID);
            
            CreateTable(
                "dbo.Producto",
                c => new
                    {
                        ProductoID = c.Int(nullable: false, identity: true),
                        SuplidorID = c.Int(nullable: false),
                        CategoriaItebisID = c.Int(nullable: false),
                        Nombre = c.String(maxLength: 100, unicode: false),
                        Precio = c.Decimal(nullable: false, precision: 10, scale: 2),
                        Estatus = c.String(maxLength: 100, unicode: false),
                        Borrado = c.Boolean(nullable: false),
                        FechaRegistro = c.DateTime(nullable: false),
                        FechaModificacion = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ProductoID)
                .ForeignKey("dbo.CategoriaItebis", t => t.CategoriaItebisID, cascadeDelete: true)
                .ForeignKey("dbo.Suplidor", t => t.SuplidorID, cascadeDelete: true)
                .Index(t => t.SuplidorID)
                .Index(t => t.CategoriaItebisID);
            
            CreateTable(
                "dbo.Suplidor",
                c => new
                    {
                        SuplidorID = c.Int(nullable: false, identity: true),
                        Nombre = c.String(maxLength: 100, unicode: false),
                        Direccion = c.String(maxLength: 500, unicode: false),
                        RNC = c.String(maxLength: 11, unicode: false),
                        Estatus = c.String(maxLength: 100, unicode: false),
                        Borrado = c.Boolean(nullable: false),
                        FechaRegistro = c.DateTime(nullable: false),
                        FechaModificacion = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.SuplidorID);
            
            CreateTable(
                "dbo.MetodoPago",
                c => new
                    {
                        MetodoPagoID = c.Int(nullable: false, identity: true),
                        Nombre = c.String(maxLength: 100, unicode: false),
                        Estatus = c.String(maxLength: 100, unicode: false),
                        Borrado = c.Boolean(nullable: false),
                        FechaRegistro = c.DateTime(nullable: false),
                        FechaModificacion = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.MetodoPagoID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Factura", "ClienteID", "dbo.Cliente");
            DropForeignKey("dbo.Factura", "MetodoPagoID", "dbo.MetodoPago");
            DropForeignKey("dbo.FacturaDetalle", "ProductoID", "dbo.Producto");
            DropForeignKey("dbo.Producto", "SuplidorID", "dbo.Suplidor");
            DropForeignKey("dbo.Producto", "CategoriaItebisID", "dbo.CategoriaItebis");
            DropForeignKey("dbo.FacturaDetalle", "FacturaID", "dbo.Factura");
            DropIndex("dbo.Producto", new[] { "CategoriaItebisID" });
            DropIndex("dbo.Producto", new[] { "SuplidorID" });
            DropIndex("dbo.FacturaDetalle", new[] { "ProductoID" });
            DropIndex("dbo.FacturaDetalle", new[] { "FacturaID" });
            DropIndex("dbo.Factura", new[] { "MetodoPagoID" });
            DropIndex("dbo.Factura", new[] { "ClienteID" });
            DropTable("dbo.MetodoPago");
            DropTable("dbo.Suplidor");
            DropTable("dbo.Producto");
            DropTable("dbo.FacturaDetalle");
            DropTable("dbo.Factura");
            DropTable("dbo.Cliente");
            DropTable("dbo.CategoriaItebis");
        }
    }
}
