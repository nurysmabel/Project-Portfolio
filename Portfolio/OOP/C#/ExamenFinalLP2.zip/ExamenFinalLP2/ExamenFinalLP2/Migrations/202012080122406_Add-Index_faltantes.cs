﻿namespace ExamenFinalLP2.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddIndex_faltantes : DbMigration
    {
        public override void Up()
        {
            CreateIndex("dbo.CategoriaItebis", "Nombre", unique: true);
            CreateIndex("dbo.MetodoPago", "Nombre", unique: true);
        }
        
        public override void Down()
        {
            DropIndex("dbo.MetodoPago", new[] { "Nombre" });
            DropIndex("dbo.CategoriaItebis", new[] { "Nombre" });
        }
    }
}
