﻿namespace ExamenFinalLP2.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddIndex : DbMigration
    {
        public override void Up()
        {
            CreateIndex("dbo.Cliente", "Correo", unique: true);
            CreateIndex("dbo.Suplidor", "RNC", unique: true);
        }
        
        public override void Down()
        {
            DropIndex("dbo.Suplidor", new[] { "RNC" });
            DropIndex("dbo.Cliente", new[] { "Correo" });
        }
    }
}
