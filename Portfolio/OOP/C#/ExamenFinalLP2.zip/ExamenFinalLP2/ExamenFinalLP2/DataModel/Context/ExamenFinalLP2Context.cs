﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using ExamenFinalLP2.DataModel.Entities;

namespace ExamenFinalLP2.DataModel.Context
{
    class ExamenFinalLP2Context:DbContext
    {
        public DbSet<Cliente> Clientes { get; set; }
        public DbSet<Factura> facturas { get; set; }
        public DbSet<FacturaDetalle> Detalles { get; set; }
        public DbSet<Producto> Productos { get; set; }
        public DbSet<Suplidor> Suplidores { get; set; }
        public DbSet<CategoriaItebis> CategoriaItebis { get; set; }
        public DbSet<MetodoPago> MetodoPagos { get; set; }
        public ExamenFinalLP2Context()
        : base("name=SQLServer")
        {

        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Properties<string>()
               .Configure(x => x.IsUnicode(false));

            modelBuilder.Properties<string>()
               .Configure(x => x.HasMaxLength(100));

            //Cliente
            modelBuilder.Entity<Cliente>()
                .HasKey(x => x.Id);

            modelBuilder.Entity<Cliente>()
                .HasMany(x => x.Facturas)
                .WithRequired(x => x.Cliente)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Cliente>()
               .ToTable("Cliente")
               .Property(x => x.Id).HasColumnName("ClienteID");

            modelBuilder.Entity<Cliente>()
                .HasIndex(u => u.Correo)
                .IsUnique();

            modelBuilder.Entity<Cliente>()
              .Property(x => x.Direccion).HasMaxLength(500);

            modelBuilder.Entity<Cliente>()
                .Property(x => x.Telefono).HasMaxLength(15);

            modelBuilder.Entity<Cliente>()
                .Property(x => x.Correo).HasMaxLength(50);

            modelBuilder.Entity<Cliente>()
              .Property(x => x.Borrado).HasColumnType("bit");

            //Metodo de pago
            modelBuilder.Entity<MetodoPago>()
                .HasKey(x => x.Id);

            modelBuilder.Entity<MetodoPago>()
               .ToTable("MetodoPago")
               .Property(x => x.Id).HasColumnName("MetodoPagoID");

            modelBuilder.Entity<MetodoPago>()
               .HasIndex(u => u.Nombre)
               .IsUnique();

            modelBuilder.Entity<MetodoPago>()
              .Property(x => x.Borrado).HasColumnType("bit");

            //Suplidor
            modelBuilder.Entity<Suplidor>()
                .HasKey(x => x.Id);

            modelBuilder.Entity<Suplidor>()
                .ToTable("Suplidor")
                .Property(x => x.Id).HasColumnName("SuplidorID");

            modelBuilder.Entity<Suplidor>()
                .HasIndex(u => u.RNC)
                .IsUnique();

            modelBuilder.Entity<Suplidor>()
              .Property(x => x.Direccion).HasMaxLength(500);

            modelBuilder.Entity<Suplidor>()
                .Property(x => x.RNC).HasMaxLength(11);

            modelBuilder.Entity<Suplidor>()
             .Property(x => x.Borrado).HasColumnType("bit");

            //CategoriaItebis
            modelBuilder.Entity<CategoriaItebis>()
                .HasKey(x => x.Id);

            modelBuilder.Entity<CategoriaItebis>()
                .ToTable("CategoriaItebis")
                .Property(x => x.Id).HasColumnName("CategoriaItebisID");

            modelBuilder.Entity<CategoriaItebis>()
               .HasIndex(u => u.Nombre)
               .IsUnique();

            modelBuilder.Entity<CategoriaItebis>()
               .Property(x => x.Nombre).HasMaxLength(50);

            modelBuilder.Entity<CategoriaItebis>()
                .Property(x => x.Porcentaje).HasColumnType("decimal").HasPrecision(10, 2);

            modelBuilder.Entity<CategoriaItebis>()
            .Property(x => x.Borrado).HasColumnType("bit");

            //Factura
            modelBuilder.Entity<Factura>()
                .HasKey(x => x.Id);

            modelBuilder.Entity<Factura>()
               .HasRequired(x => x.MetodoPago);

            modelBuilder.Entity<Factura>()
                .HasRequired(x => x.Cliente)
                .WithMany(x => x.Facturas)
                .HasForeignKey(x => x.ClienteID)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Factura>()
                .HasMany(x => x.FacturaDetalles)
                .WithRequired(x => x.Factura)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Factura>()
               .ToTable("Factura")
               .Property(x => x.Id).HasColumnName("FacturaID");

            modelBuilder.Entity<Factura>()
               .Property(x => x.Borrado).HasColumnType("bit");


            //Producto
            modelBuilder.Entity<Producto>()
                .HasKey(x => x.Id);

            modelBuilder.Entity<Producto>()
                .HasRequired(x => x.Suplidor);

            modelBuilder.Entity<Producto>()
                .HasRequired(x => x.CategoriaItebis);

            modelBuilder.Entity<Producto>()
               .ToTable("Producto")
               .Property(x => x.Id).HasColumnName("ProductoID");

            modelBuilder.Entity<Producto>()
                .Property(x => x.Precio).HasColumnType("decimal").HasPrecision(10, 2);

            modelBuilder.Entity<Producto>()
             .Property(x => x.Borrado).HasColumnType("bit");

            //FacturaDetalle
            modelBuilder.Entity<FacturaDetalle>()
               .HasKey(x => x.Id);

            modelBuilder.Entity<FacturaDetalle>()
                .HasRequired(x => x.Factura)
                .WithMany(x => x.FacturaDetalles)
                .HasForeignKey(x => x.FacturaID)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<FacturaDetalle>()
                .HasRequired(x => x.Producto);

            modelBuilder.Entity<FacturaDetalle>()
             .ToTable("FacturaDetalle")
             .Property(x => x.Id).HasColumnName("FacturaDetalleID");

            modelBuilder.Entity<FacturaDetalle>()
                .Property(x => x.Precio).HasColumnType("decimal").HasPrecision(10, 2);

            modelBuilder.Entity<FacturaDetalle>()
               .Property(x => x.Borrado).HasColumnType("bit");
        }
    }
}
