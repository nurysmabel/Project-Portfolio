﻿using ExamenFinalLP2.DataModel.Entities;
using ExamenFinalLP2.DataModel.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFinalLP2.DataModel.Repositories
{
    class SuplidorRepository : GenericRepository<Suplidor>, ISuplidorRepository
    {
        public int GetId(string _nombre)
        {
            return db.Where(x => x.Borrado == false).FirstOrDefault(x => x.Nombre == _nombre).Id;
        }

        public List<Suplidor> GetSuplidores()
        {
            List<Suplidor> Suplidores = new List<Suplidor>();
            Suplidores = GetAll().ToList();
            return Suplidores;
        }

        public List<string> GetSuplidoresNames()
        {
            List<string> Suplidoresnames = new List<string>();
            Suplidoresnames = GetAll().Select(x => x.Nombre).ToList();
            return Suplidoresnames;
        }
    }
}
