﻿using ExamenFinalLP2.DataModel.Entities;
using ExamenFinalLP2.DataModel.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFinalLP2.DataModel.Repositories
{
    class CategoriaItebisRepository : GenericRepository<CategoriaItebis>, ICategoriaItebisRepository
    {
        public List<CategoriaItebis> GetCategoriaItebis()
        {
            List<CategoriaItebis> CategoriaItebis = new List<CategoriaItebis>();
            CategoriaItebis = GetAll().ToList();
            return CategoriaItebis;
        }

        public List<string> GetCategoriasNames()
        {
            List<string> CategoriaItebis = new List<string>();
            CategoriaItebis = GetAll().Select(x => x.Nombre).ToList();
            return CategoriaItebis;
        }

        public int GetId(string _nombre)
        {
            return db.Where(x => x.Borrado == false).FirstOrDefault(x => x.Nombre == _nombre).Id;
        }
    }
}
