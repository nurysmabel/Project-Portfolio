﻿using ExamenFinalLP2.DataModel.Entities;
using ExamenFinalLP2.DataModel.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFinalLP2.DataModel.Repositories
{
    class FacturaRepository : GenericRepository<Factura>, IFacturaRepository
    {
        public List<Factura> GetFacturas()
        {
            List<Factura> Facturas = new List<Factura>();
            Facturas = GetAll().ToList();
            return Facturas;
        }

        public List<Factura> GetFacturasbycliente(int _id)
        {
            List<Factura> Facturas = new List<Factura>();
            Facturas = GetAll(x => x.FacturaDetalles, x => x.Cliente).Where(x => x.ClienteID == _id).ToList();
            return Facturas;
        }
    }
}
