﻿using ExamenFinalLP2.DataModel.Context;
using ExamenFinalLP2.DataModel.Entities;
using ExamenFinalLP2.DataModel.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFinalLP2.DataModel.Repositories
{
    class MetodoPagoRepository : GenericRepository<MetodoPago>, IMetodoPagoRepository
    {
        public int GetID(string _nombre)
        {
            return db.Where(x => x.Borrado == false).FirstOrDefault(x => x.Nombre == _nombre).Id;
        }

        public List<MetodoPago> GetMetodos()
        {
            List<MetodoPago> MetodoPagos = new List<MetodoPago>();
            MetodoPagos = GetAll().ToList();
            return MetodoPagos;
        }

        public List<string> GetMetodosNames()
        {
            List<string> MetodosPagos = new List<string>();
            MetodosPagos = GetAll().Select(x => x.Nombre).ToList();
            return MetodosPagos;
        }
    }
}
