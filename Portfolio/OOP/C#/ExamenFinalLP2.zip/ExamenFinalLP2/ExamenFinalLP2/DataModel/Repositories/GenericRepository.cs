﻿using ExamenFinalLP2.DataModel.Context;
using ExamenFinalLP2.DataModel.Entities;
using ExamenFinalLP2.DataModel.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFinalLP2
{
    public class GenericRepository<T> : IGeneric<T> where T : Base
    {

        private ExamenFinalLP2Context finalLP2Context;
        public DbSet<T> db;
        public GenericRepository()
        {
            finalLP2Context = new ExamenFinalLP2Context();
            db = finalLP2Context.Set<T>();
        }
        public T Create(T _model)
        {
            db.Add(_model);
            finalLP2Context.SaveChanges();

            return _model;
        }

        public OperationResult Delete(T _model)
        {
            try
            {
                finalLP2Context.Entry(_model).CurrentValues.SetValues(_model);
                finalLP2Context.Entry(_model).State = EntityState.Modified;
                _model.Borrado = true;
                _model.FechaModificacion = DateTime.Now;
                finalLP2Context.SaveChanges();
                return new OperationResult() { Data = _model, Message = "Borrado exitosamente", Result = true };
            }
            catch (Exception)
            {
                return new OperationResult() { Data = _model, Message = "Ha ocurrido un error en el borrado", Result = false };
            }

        }

        public T FindbyID(int _ID)
        {
            return db.Where(x => x.Borrado == false).FirstOrDefault(x => x.Id == _ID);
        }

        public IQueryable<T> GetAll(params Expression<Func<T, object>>[] Propiedades)
        {
            var set = db.AsQueryable();

            foreach (var propiedad in Propiedades)
            {
                set = set.Include(propiedad);
            }
            return set.Where(x => x.Borrado == false);
        }

        public OperationResult Update(T _model)
        {
            var entidadactual = FindbyID(_model.Id);
            try
            {
                finalLP2Context.Entry(entidadactual).CurrentValues.SetValues(_model);
                finalLP2Context.Entry(entidadactual).State = EntityState.Modified;
                entidadactual = _model;
                finalLP2Context.SaveChanges();
                return new OperationResult() { Data = _model, Message = "Actualizado exitosamente", Result = true };
            }
            catch (Exception)
            {
                return new OperationResult() { Data = entidadactual, Message = "Ha ocurrido un error en la actualización", Result = false };
            }
        }
    }
}
