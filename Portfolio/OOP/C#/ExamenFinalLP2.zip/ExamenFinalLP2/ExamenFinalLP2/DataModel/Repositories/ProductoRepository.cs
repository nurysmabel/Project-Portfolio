﻿using ExamenFinalLP2.DataModel.Entities;
using ExamenFinalLP2.DataModel.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFinalLP2.DataModel.Repositories
{
    class ProductoRepository : GenericRepository<Producto>, IProductoRepository
    {
        public int GetID(string _nombre)
        {
            return db.Where(x => x.Borrado == false).FirstOrDefault(x => x.Nombre == _nombre).Id;
        }

        public List<Producto> GetProductos()
        {
            List<Producto> ProductosNames = new List<Producto>();
            ProductosNames = GetAll().ToList();
            return ProductosNames;
        }

        public List<string> GetProductosNames()
        {
            List<string> ProductosNames = new List<string>();
            ProductosNames = GetAll().Select(x => x.Nombre).ToList();
            return ProductosNames;
        }
    }
}
