﻿using ExamenFinalLP2.DataModel.Entities;
using ExamenFinalLP2.DataModel.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFinalLP2.DataModel.Repositories
{
    class FacturaDetalleRepository : GenericRepository<FacturaDetalle>, IFacturaDetalleRepository
    {
        public List<FacturaDetalle> GetfacturaDetallesByFactura(int _id)
        {
            List<FacturaDetalle> detalles = new List<FacturaDetalle>();
            detalles = GetAll().Where(x => x.FacturaID == _id).ToList();
            return detalles;
        }

        OperationResult IFacturaDetalleRepository.DeleteMulti(List<FacturaDetalle> detalles)
        {
            try
            {
                foreach (var item in detalles)
                {
                    Delete(item);
                }
            }
            catch (Exception)
            {
                return new OperationResult() { Data = detalles, Message = "Error en el borrado de múltiples Facturas Detalles", Result = false };
            }
            
            return new OperationResult() { Data = detalles, Message = "FacturasDetalles borradas exitosamente", Result = true };
        }

        List<FacturaDetalle> IFacturaDetalleRepository.GetfacturaDetalles()
        {
            List<FacturaDetalle> Detalles = new List<FacturaDetalle>();
            Detalles = GetAll().ToList();
            return Detalles;
        }
    }
}
