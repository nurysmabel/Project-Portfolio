﻿using ExamenFinalLP2.DataModel.Entities;
using ExamenFinalLP2.DataModel.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFinalLP2.DataModel.Repositories
{
    class ClienteRepository : GenericRepository<Cliente>, IClienteRepository
    {
        public List<Cliente> GetClientes()
        {
            List<Cliente> clientes = new List<Cliente>();
            clientes = GetAll().ToList();
            return clientes; 
        }
    }
}
