﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFinalLP2.DataModel.Entities
{
    public class Cliente:Base
    {
        private Cliente cliente;

        public Cliente()
        {

        }

        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public string Correo { get; set; }
        public List<Factura> Facturas { get; set; }
    }
}
