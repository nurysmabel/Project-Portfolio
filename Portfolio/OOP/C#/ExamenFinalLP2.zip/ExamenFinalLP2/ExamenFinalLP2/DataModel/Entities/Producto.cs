﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFinalLP2.DataModel.Entities
{
    public class Producto:Base
    {
        public int SuplidorID { get; set; }
        public int CategoriaItebisID { get; set; }
        public CategoriaItebis CategoriaItebis { get; set; }
        public Suplidor Suplidor { get; set; }
        public string Nombre { get; set; }
        public decimal Precio { get; set; }
    }
}
