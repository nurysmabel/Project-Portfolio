﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFinalLP2.DataModel.Entities
{
    public class Suplidor:Base
    {
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string RNC { get; set; }
        public List<Producto> Productos { get; set; }
    }
}
