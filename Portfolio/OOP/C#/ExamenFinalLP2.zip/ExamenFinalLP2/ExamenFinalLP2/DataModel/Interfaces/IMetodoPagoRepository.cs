﻿using ExamenFinalLP2.DataModel.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFinalLP2.DataModel.Interfaces
{
    interface IMetodoPagoRepository:IGeneric<MetodoPago>
    {
        List<MetodoPago> GetMetodos();
        List<string> GetMetodosNames();
        int GetID(string _nombre);
    }
}
