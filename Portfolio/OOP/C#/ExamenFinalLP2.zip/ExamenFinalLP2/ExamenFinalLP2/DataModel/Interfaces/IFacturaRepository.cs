﻿using ExamenFinalLP2.DataModel.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFinalLP2.DataModel.Interfaces
{
    interface IFacturaRepository:IGeneric<Factura>
    {
        List<Factura> GetFacturas();
        List<Factura> GetFacturasbycliente(int _id);
    }
}
