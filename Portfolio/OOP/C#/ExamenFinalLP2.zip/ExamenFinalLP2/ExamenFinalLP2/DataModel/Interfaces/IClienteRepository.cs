﻿using ExamenFinalLP2.DataModel.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFinalLP2.DataModel.Interfaces
{
    interface IClienteRepository:IGeneric<Cliente>
    {
        List<Cliente> GetClientes();
    }
}
