﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFinalLP2.DataModel.Interfaces
{
    interface IGeneric<T>
    {
        T Create(T _model);
        IQueryable<T> GetAll(params Expression<Func<T, object>>[] Propiedades);
        T FindbyID(int _ID);
        OperationResult Update(T _model);
        OperationResult Delete(T _model);
    }
}
