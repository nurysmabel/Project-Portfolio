﻿using ExamenFinalLP2.DataModel.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFinalLP2.DataModel.Interfaces
{
    interface ISuplidorRepository:IGeneric<Suplidor>
    {
        List<Suplidor> GetSuplidores();
        int GetId(string _nombre);
        List<string> GetSuplidoresNames();
    }
}
