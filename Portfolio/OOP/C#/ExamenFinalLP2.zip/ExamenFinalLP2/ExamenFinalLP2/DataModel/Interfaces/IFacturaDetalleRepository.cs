﻿using ExamenFinalLP2.DataModel.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFinalLP2.DataModel.Interfaces
{
    interface IFacturaDetalleRepository:IGeneric<FacturaDetalle>
    {
        List<FacturaDetalle> GetfacturaDetalles();
        OperationResult DeleteMulti(List<FacturaDetalle> detalles);
        List<FacturaDetalle> GetfacturaDetallesByFactura(int _id);
    }
}
