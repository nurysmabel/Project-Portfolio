﻿using ExamenFinalLP2.DataModel.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFinalLP2.DataModel.Interfaces
{
    interface ICategoriaItebisRepository:IGeneric<CategoriaItebis>
    {
        List<string> GetCategoriasNames();
        List<CategoriaItebis> GetCategoriaItebis();
        int GetId(string _nombre);
    }
}
