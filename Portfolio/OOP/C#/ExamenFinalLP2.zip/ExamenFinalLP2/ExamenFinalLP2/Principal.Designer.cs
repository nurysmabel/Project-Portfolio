﻿namespace ExamenFinalLP2
{
    partial class Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Principal));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.gestionarEntidadesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestionarClientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestionarMétodosDePagosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestionarSuplidorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestionarCategoríaItebisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestionarProductoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generarFlujoPrincipalCrearFacturasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gestionarEntidadesToolStripMenuItem,
            this.generarFlujoPrincipalCrearFacturasToolStripMenuItem});
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Name = "menuStrip1";
            // 
            // gestionarEntidadesToolStripMenuItem
            // 
            this.gestionarEntidadesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gestionarClientesToolStripMenuItem,
            this.gestionarMétodosDePagosToolStripMenuItem,
            this.gestionarSuplidorToolStripMenuItem,
            this.gestionarCategoríaItebisToolStripMenuItem,
            this.gestionarProductoToolStripMenuItem});
            this.gestionarEntidadesToolStripMenuItem.Name = "gestionarEntidadesToolStripMenuItem";
            resources.ApplyResources(this.gestionarEntidadesToolStripMenuItem, "gestionarEntidadesToolStripMenuItem");
            // 
            // gestionarClientesToolStripMenuItem
            // 
            this.gestionarClientesToolStripMenuItem.Name = "gestionarClientesToolStripMenuItem";
            resources.ApplyResources(this.gestionarClientesToolStripMenuItem, "gestionarClientesToolStripMenuItem");
            this.gestionarClientesToolStripMenuItem.Click += new System.EventHandler(this.gestionarClientesToolStripMenuItem_Click);
            // 
            // gestionarMétodosDePagosToolStripMenuItem
            // 
            this.gestionarMétodosDePagosToolStripMenuItem.Name = "gestionarMétodosDePagosToolStripMenuItem";
            resources.ApplyResources(this.gestionarMétodosDePagosToolStripMenuItem, "gestionarMétodosDePagosToolStripMenuItem");
            this.gestionarMétodosDePagosToolStripMenuItem.Click += new System.EventHandler(this.gestionarMétodosDePagosToolStripMenuItem_Click);
            // 
            // gestionarSuplidorToolStripMenuItem
            // 
            this.gestionarSuplidorToolStripMenuItem.Name = "gestionarSuplidorToolStripMenuItem";
            resources.ApplyResources(this.gestionarSuplidorToolStripMenuItem, "gestionarSuplidorToolStripMenuItem");
            this.gestionarSuplidorToolStripMenuItem.Click += new System.EventHandler(this.gestionarSuplidorToolStripMenuItem_Click);
            // 
            // gestionarCategoríaItebisToolStripMenuItem
            // 
            this.gestionarCategoríaItebisToolStripMenuItem.Name = "gestionarCategoríaItebisToolStripMenuItem";
            resources.ApplyResources(this.gestionarCategoríaItebisToolStripMenuItem, "gestionarCategoríaItebisToolStripMenuItem");
            this.gestionarCategoríaItebisToolStripMenuItem.Click += new System.EventHandler(this.gestionarCategoríaItebisToolStripMenuItem_Click);
            // 
            // gestionarProductoToolStripMenuItem
            // 
            this.gestionarProductoToolStripMenuItem.Name = "gestionarProductoToolStripMenuItem";
            resources.ApplyResources(this.gestionarProductoToolStripMenuItem, "gestionarProductoToolStripMenuItem");
            this.gestionarProductoToolStripMenuItem.Click += new System.EventHandler(this.gestionarProductoToolStripMenuItem_Click);
            // 
            // generarFlujoPrincipalCrearFacturasToolStripMenuItem
            // 
            this.generarFlujoPrincipalCrearFacturasToolStripMenuItem.Name = "generarFlujoPrincipalCrearFacturasToolStripMenuItem";
            resources.ApplyResources(this.generarFlujoPrincipalCrearFacturasToolStripMenuItem, "generarFlujoPrincipalCrearFacturasToolStripMenuItem");
            this.generarFlujoPrincipalCrearFacturasToolStripMenuItem.Click += new System.EventHandler(this.generarFlujoPrincipalCrearFacturasToolStripMenuItem_Click);
            // 
            // Principal
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Principal";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem gestionarEntidadesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestionarClientesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestionarMétodosDePagosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestionarSuplidorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestionarCategoríaItebisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestionarProductoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem generarFlujoPrincipalCrearFacturasToolStripMenuItem;
    }
}

