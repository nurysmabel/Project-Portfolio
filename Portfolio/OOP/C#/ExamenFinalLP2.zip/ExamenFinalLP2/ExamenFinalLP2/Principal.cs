﻿using ExamenFinalLP2.DataModel.Interfaces;
using ExamenFinalLP2.DataModel.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExamenFinalLP2
{
    public partial class Principal : Form
    {
        IClienteRepository Cliente = new ClienteRepository();
        IProductoRepository Producto = new ProductoRepository();
        IMetodoPagoRepository MetodoPago = new MetodoPagoRepository();
        ISuplidorRepository Suplidor = new SuplidorRepository();
        ICategoriaItebisRepository Categoria = new CategoriaItebisRepository();
        public Principal()
        {
            InitializeComponent();
        }

        private void generarFlujoPrincipalCrearFacturasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Cliente.GetClientes().Count == 0 || Producto.GetProductos().Count == 0 || MetodoPago.GetMetodos().Count == 0)
            {
                MessageBox.Show("Es necesario tener por lo menos registrado un producto, cliente y un metodo de pago para crear una factura");
            }
            else
            {
               GestiónClientes gestiónClientes = new GestiónClientes();
               gestiónClientes.ShowDialog();
            }
        }

        private void gestionarProductoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Categoria.GetCategoriaItebis().Count == 0 || Suplidor.GetSuplidores().Count == 0)
            {
                MessageBox.Show("Es necesario tener por lo menos registrado un Suplidor y una CategoriaItebis para gestionar un producto");
            }
            else
            {
                frmProductos productos = new frmProductos();
                productos.ShowDialog();
            }
        }

        private void gestionarCategoríaItebisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCategoriaITEBIS iTEBIS = new frmCategoriaITEBIS();
            iTEBIS.ShowDialog();
        }

        private void gestionarSuplidorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSuplidor suplidor = new frmSuplidor();
            suplidor.ShowDialog();
        }

        private void gestionarMétodosDePagosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GestionarMetodoDepago metodoDepago = new GestionarMetodoDepago();
            metodoDepago.ShowDialog();
        }

        private void gestionarClientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCliente cliente = new frmCliente();
            cliente.ShowDialog();
        }
    }
}
