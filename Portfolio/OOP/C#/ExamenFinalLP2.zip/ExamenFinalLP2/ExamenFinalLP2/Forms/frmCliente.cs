﻿using ExamenFinalLP2.DataModel.Entities;
using ExamenFinalLP2.DataModel.Interfaces;
using ExamenFinalLP2.DataModel.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExamenFinalLP2
{

    
    public partial class frmCliente : Form
    {
        IClienteRepository Cliente = new ClienteRepository();
        Cliente clienteSelect;
        public frmCliente()
        {
            InitializeComponent();
        }

        private void frmCliente_Load(object sender, EventArgs e)
        {
            ListClientesload();
            btnDelete.Enabled = false;
            btnReset.Enabled = false;
            btnUpdate.Enabled = false;
        }

        private void ListClientesload()
        {
            Resetload();

        }

        private void Resetload()
        {
            dbvClientes.DataSource = Cliente.GetClientes().Select(p => new { p.Id, p.Nombre, p.Apellido,  p.Telefono, p.Correo, p.Direccion, p.Estatus, p.FechaNacimiento, p.FechaRegistro, p.FechaModificacion}).ToList();
            dbvClientes.ClearSelection();
            txtClienteID.Text = "";
            txtNombre.Text = "";
            txtApellido.Text = "";
            txtCorreo.Text = "";
            txtTel.Text = "";
            txtDireccion.Text = "";
            dateNacimiento.Value = DateTime.Now;
            btnDelete.Enabled = false;
            btnReset.Enabled = false;
            btnUpdate.Enabled = false;
            btnCreate.Enabled = true;
        }

        private void dbvClientes_SelectionChanged(object sender, EventArgs e)
        {
            btnDelete.Enabled = true;
            btnReset.Enabled = true;
            btnUpdate.Enabled = true;
            btnCreate.Enabled = false;
            txtClienteID.Text = dbvClientes.CurrentRow.Cells["Id"].Value.ToString();
            clienteSelect = Cliente.FindbyID(int.Parse(txtClienteID.Text));
            if (!(clienteSelect == null)) 
            {
                txtNombre.Text = clienteSelect.Nombre;
                txtApellido.Text = clienteSelect.Apellido;
                txtCorreo.Text = clienteSelect.Correo;
                txtTel.Text = clienteSelect.Telefono;
                txtDireccion.Text = clienteSelect.Direccion;
                dateNacimiento.Value = clienteSelect.FechaNacimiento;
            } 
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                Cliente.Create(new Cliente() { Nombre = txtNombre.Text, Apellido = txtApellido.Text, Correo = txtCorreo.Text, Telefono = txtTel.Text, Direccion = txtDireccion.Text, FechaNacimiento = dateNacimiento.Value, Estatus = "A", Borrado = false, FechaRegistro = DateTime.Now, FechaModificacion = DateTime.Now });
                ListClientesload();
                MessageBox.Show("El cliente ha sido creado satisfactoriamente");
            }
            catch (Exception)
            {
                MessageBox.Show("Ha ocurrido un error en la creación del cliente, puede ser que algún dato esté repetido o vacío");
            }
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Cliente.Update(new Cliente()
                {
                    Nombre = txtNombre.Text,
                    Apellido = txtApellido.Text,
                    Correo = txtCorreo.Text,
                    Telefono = txtTel.Text,
                    Direccion = txtDireccion.Text,
                    FechaNacimiento = dateNacimiento.Value,
                    FechaModificacion = DateTime.Now,
                    Borrado = clienteSelect.Borrado,
                    Estatus = clienteSelect.Estatus,
                    Facturas = clienteSelect.Facturas,
                    Id = clienteSelect.Id,
                    FechaRegistro = clienteSelect.FechaRegistro
                }
           );
                ListClientesload();
                MessageBox.Show("El cliente ha sido actualizado satisfactoriamente");
            }
            catch (Exception)
            {
                MessageBox.Show("Ha ocurrido un error en la actualización del cliente, puede ser que algún dato esté repetido");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var cliente = Cliente.FindbyID(int.Parse(txtClienteID.Text));
            Cliente.Delete(cliente);
            ListClientesload();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ListClientesload();
        }
    }
}
