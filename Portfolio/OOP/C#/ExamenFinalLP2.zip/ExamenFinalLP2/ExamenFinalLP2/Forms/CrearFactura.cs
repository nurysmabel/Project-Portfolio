﻿using ExamenFinalLP2.DataModel.Entities;
using ExamenFinalLP2.DataModel.Interfaces;
using ExamenFinalLP2.DataModel.Repositories;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace ExamenFinalLP2
{
    public partial class CrearFactura : Form
    {
        IFacturaRepository factura = new FacturaRepository();
        IFacturaDetalleRepository facturaDetalle = new FacturaDetalleRepository();
        IProductoRepository producto = new ProductoRepository();
        IMetodoPagoRepository metodo = new MetodoPagoRepository();
        ICategoriaItebisRepository Categoria = new CategoriaItebisRepository();
        private List<Producto> productosTemp = new List<Producto>();
        private List<Producto> Productos = new List<Producto>();

        public CrearFactura(int _id)
        {
            InitializeComponent();
            txtCliente.Text = _id.ToString();
            Productos = producto.GetAll(x => x.CategoriaItebis).ToList();
        }

        public new void AutoValidate() 
        {
            if (productosTemp.Count > 0 && cbMetodos.SelectedIndex >= 0)
            {
                btnCrear.Enabled = true;
            }
            else
            {
                btnCrear.Enabled = false;
            }
        }

        private void cbMetodos_SelectedIndexChanged(object sender, EventArgs e)
        {
            AutoValidate();
        }

        private void CrearFactura_Load(object sender, EventArgs e)
        {
            dgvProductos.DataSource = (from r in Productos select new { r.Id, r.Nombre, r.Precio, r.CategoriaItebis.Porcentaje }).ToList();
            btnCrear.Enabled = false;
            btnInsertarProducto.Enabled = false;
            btnQuitarProducto.Enabled = false;
            cbMetodos.DataSource = metodo.GetMetodosNames();
        }

        private void btnInsertarProducto_Click(object sender, EventArgs e)
        {
            productosTemp.Add(Productos.FirstOrDefault(x => x.Id == (int)dgvProductos.CurrentRow.Cells["Id"].Value));
            var q = from x in productosTemp
                    group x by x into g
                    let Cantidad = g.Count()
                    let ITBIS = g.Key.Precio * Cantidad * g.Key.CategoriaItebis.Porcentaje
                    let Subtotal = g.Key.Precio * Cantidad
                    orderby Cantidad descending
                    select new
                    {
                        Nombre = g.Key.Nombre,
                        Cantidad = Cantidad,
                        Precio = g.Key.Precio,
                        Porcentaje = g.Key.CategoriaItebis.Porcentaje,
                        ITBIS,
                        Subtotal,
                        Total = ITBIS + Subtotal
                    };
            dgvProductosSelect.DataSource = q.ToList();
        }

        private void btnQuitarProducto_Click(object sender, EventArgs e)
        {
            productosTemp.Remove(producto.FindbyID((int)dgvProductos.CurrentRow.Cells["Id"].Value));
            var q = from x in productosTemp
                    group x by x into g
                    let Cantidad = g.Count()
                    let ITBIS = g.Key.Precio * Cantidad * g.Key.CategoriaItebis.Porcentaje
                    let Subtotal = g.Key.Precio * Cantidad
                    orderby Cantidad descending
                    select new
                    {
                        Nombre = g.Key.Nombre,
                        Cantidad = Cantidad,
                        Precio = g.Key.Precio,
                        Porcentaje = g.Key.CategoriaItebis.Porcentaje,
                        ITBIS,
                        Subtotal,
                        Total = ITBIS + Subtotal
                    };
            dgvProductosSelect.DataSource = q.ToList();

            if (productosTemp.Count < 0)
            {
                AutoValidate();
            }
        }
        
        private void dgvProductos_SelectionChanged(object sender, EventArgs e)
        {
            btnInsertarProducto.Enabled = true;
            btnQuitarProducto.Enabled = true;
            AutoValidate();
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            try
            {
                var q = from x in productosTemp
                        group x by x into g
                        let Cantidad = g.Count()
                        let ITBIS = g.Key.Precio * Cantidad * g.Key.CategoriaItebis.Porcentaje
                        let Subtotal = g.Key.Precio * Cantidad
                        orderby Cantidad descending
                        select new
                        {
                            Nombre = g.Key.Nombre,
                            Cantidad = Cantidad,
                            Precio = g.Key.Precio,
                            Porcentaje = g.Key.CategoriaItebis.Porcentaje,
                            ITBIS,
                            Subtotal,
                            Total = ITBIS + Subtotal
                        };
                List<FacturaDetalle> facturaDetalles = new List<FacturaDetalle>();

                foreach (var productos in q)
                {
                    facturaDetalles.Add(new FacturaDetalle()
                    {
                        ProductoID = producto.GetID(productos.Nombre),
                        Cantidad = productos.Cantidad,
                        FechaRegistro = DateTime.Now,
                        FechaModificacion = DateTime.Now,
                        Borrado = false,
                        Estatus = "A",
                        Precio = productos.Total
                    });
                }
                //Crear factura actual
                Factura facturaGenerada = new Factura()
                {
                    MetodoPagoID = metodo.GetID(cbMetodos.Text),
                    ClienteID = int.Parse(txtCliente.Text),
                    Estatus = "A",
                    Borrado = false,
                    FechaRegistro = DateTime.Now,
                    FechaModificacion = DateTime.Now,
                    FacturaDetalles = facturaDetalles
                };
                factura.Create(facturaGenerada);
                MessageBox.Show("Factura creada Exitosamente");
            }
            catch (Exception)
            {

                MessageBox.Show("Error en el creación de la factura");
            }
        }
    }
}
