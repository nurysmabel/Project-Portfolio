﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ExamenFinalLP2.DataModel.Entities;
using ExamenFinalLP2.DataModel.Interfaces;
using ExamenFinalLP2.DataModel.Repositories;

namespace ExamenFinalLP2
{
    public partial class frmCategoriaITEBIS : Form
    {
        ICategoriaItebisRepository Itbis = new CategoriaItebisRepository();
        CategoriaItebis ItbisSelect;
        public frmCategoriaITEBIS()
        {
            InitializeComponent();
        }

        private void btCreate_Click(object sender, EventArgs e)
        {
            try
            {
                Itbis.Create(new CategoriaItebis() { Nombre = txtNombre.Text, Porcentaje = nudItbis.Value, Borrado = false, Estatus = "A", FechaModificacion = DateTime.Now, FechaRegistro = DateTime.Now });
                ListItbisLoad();
                MessageBox.Show("Creación de la categoría ITEBIS realizada con éxito");
            }
            catch (Exception)
            {
                MessageBox.Show("Ha ocurrido un error en la creación de la categoría ITEBIS, puede ser que algún dato esté repetido o vacío");
            }
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                ItbisSelect.Nombre = txtNombre.Text;
                ItbisSelect.Porcentaje = nudItbis.Value;
                ItbisSelect.FechaModificacion = DateTime.Now;
                Itbis.Update(ItbisSelect);
                ListItbisLoad();
                MessageBox.Show("Actualización de la categoría ITEBIS realizada con éxito");
            }
            catch (Exception)
            {
                MessageBox.Show("Error en la actualización de la categoría ITEBIS, puede ser que algún dato esté repetido");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Itbis.Delete(ItbisSelect);
            ListItbisLoad();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetLoad();
        }

        private void ListItbisLoad()
        {
            dvbItebis.DataSource = Itbis.GetCategoriaItebis().Select(x => new { x.Id, x.Nombre, x.Porcentaje, x.Borrado, x.Estatus, x.FechaRegistro, x.FechaModificacion }).ToList();
        }

        private void ResetLoad()
        {
            ListItbisLoad();
            dvbItebis.ClearSelection();
            txtID.Text = "";
            txtNombre.Text = "";
            nudItbis.Value = 0;
            btnDelete.Enabled = false;
            btnReset.Enabled = false;
            btnUpdate.Enabled = false;
            btCreate.Enabled = true;
        }

        private void frmCategoriaITEBIS_Load(object sender, EventArgs e)
        {
            ListItbisLoad();
            ResetLoad();
        }

        private void dvbItebis_SelectionChanged(object sender, EventArgs e)
        {
            ItbisSelect = Itbis.FindbyID(((int) dvbItebis.CurrentRow.Cells["Id"].Value));

            if (ItbisSelect == null)
            {
                MessageBox.Show("Categoria ITBIS seleccionado ha sido borrado.");
            }
            else
            {

                btnDelete.Enabled = true;
                btnReset.Enabled = true;
                btnUpdate.Enabled = true;
                btCreate.Enabled = false;
                txtID.Text = ItbisSelect.Id.ToString();
                txtNombre.Text = ItbisSelect.Nombre.ToString();
                nudItbis.Value = ItbisSelect.Porcentaje;
            }
        }
    }
}
    
