﻿using ExamenFinalLP2.DataModel.Entities;
using ExamenFinalLP2.DataModel.Interfaces;
using ExamenFinalLP2.DataModel.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExamenFinalLP2
{
    public partial class GestionarFacturas : Form
    {
        IFacturaRepository Factura = new FacturaRepository();
        IFacturaDetalleRepository FacturaDetalle = new FacturaDetalleRepository();
        List<Factura> facturas;
        public GestionarFacturas(int _idCliente)
        {
            facturas = Factura.GetFacturasbycliente(_idCliente);
            InitializeComponent();
        }
        private void btnDetalle_Click(object sender, EventArgs e)
        {
            GestionarDetalles gestionarDetalles = new GestionarDetalles((int)dgvFacturas.CurrentRow.Cells["Id"].Value);
            gestionarDetalles.ShowDialog();
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(FacturaDetalle.DeleteMulti(FacturaDetalle.GetfacturaDetallesByFactura((int)dgvFacturas.CurrentRow.Cells["Id"].Value)).Message);
            
            MessageBox.Show(Factura.Delete(Factura.FindbyID((int)dgvFacturas.CurrentRow.Cells["Id"].Value)).Message);
        }

        private void GestionarFacturas_Load(object sender, EventArgs e)
        {
            dgvFacturas.DataSource = facturas;
            Resetload();
        }

        private void Resetload()
        {
            dgvFacturas.DataSource = facturas.Select(p => new { p.Id, p.ClienteID, p.Cliente.Nombre, p.Estatus, p.FechaRegistro, p.FechaModificacion }).ToList();
            dgvFacturas.ClearSelection();
            btnBorrar.Enabled = false;
            btnDetalle.Enabled = false;
        }

        private void dgvFacturas_SelectionChanged(object sender, EventArgs e)
        {
            btnBorrar.Enabled = true;
            btnDetalle.Enabled = true;
        }
    }
}
