﻿using ExamenFinalLP2.DataModel.Entities;
using ExamenFinalLP2.DataModel.Interfaces;
using ExamenFinalLP2.DataModel.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExamenFinalLP2
{
   
    public partial class GestionarDetalles : Form
    {
        IFacturaDetalleRepository FacturaDetalle = new FacturaDetalleRepository();
        List<FacturaDetalle> detalles;
        public GestionarDetalles(int _id)
        {
            detalles = FacturaDetalle.GetfacturaDetallesByFactura(_id);
            InitializeComponent();
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(FacturaDetalle.Delete(FacturaDetalle.FindbyID((int)dgvDetalles.CurrentRow.Cells["Id"].Value)).Message);
        }

        private void GestionarDetalles_Load(object sender, EventArgs e)
        {
            btnBorrar.Enabled = false;
            dgvDetalles.DataSource = detalles.Select(p => new { p.Id, p.FacturaID,p.ProductoID, p.Cantidad, p.Precio, p.Estatus, p.FechaRegistro, p.FechaModificacion }).ToList();
            nudTotal.Value = detalles.Select(x => x.Precio).Sum();
        }

        private void dgvDetalles_SelectionChanged(object sender, EventArgs e)
        {
            btnBorrar.Enabled = true;
        }
    }
}
