﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ExamenFinalLP2.DataModel.Interfaces;
using ExamenFinalLP2.DataModel.Repositories;
using ExamenFinalLP2.DataModel.Entities;

namespace ExamenFinalLP2
{
    public partial class GestionarMetodoDepago : Form
    {
        IMetodoPagoRepository pago = new MetodoPagoRepository();
        MetodoPago PagoSelect;
        public GestionarMetodoDepago()
        {
            InitializeComponent();
        }

        private void btCreate_Click(object sender, EventArgs e)
        {
            try
            {
                pago.Create(new MetodoPago() { Nombre = txtNombre.Text, Borrado = false, Estatus = "A", FechaModificacion = DateTime.Now, FechaRegistro = DateTime.Now });
                ListaPagoLoad();
                MessageBox.Show("Creación del método de pago realizada con éxito");
            }
            catch (Exception)
            {
                MessageBox.Show("Error en la creación del método de pago, puede ser que algún dato esté repetido o vacío");
            }
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                PagoSelect.Nombre = txtNombre.Text;
                PagoSelect.FechaModificacion = DateTime.Now;
                pago.Update(PagoSelect);
                ListaPagoLoad();
                MessageBox.Show("Actualización del método de pago realizada con éxito");
            }
            catch (Exception)
            {
                MessageBox.Show("Error en la actualización del método de pago, puede ser que algún dato esté repetido");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            pago.Delete(PagoSelect);
            ListaPagoLoad();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetLoad();
        }

        private void ListaPagoLoad()
        {
            dgvMetodos.DataSource = pago.GetMetodos().Select(x => new { x.Id, x.Nombre, x.Borrado, x.Estatus, x.FechaRegistro, x.FechaModificacion }).ToList();
        }

        private void ResetLoad()
        {
            ListaPagoLoad();
            dgvMetodos.ClearSelection();
            txtId.Text = "";
            txtNombre.Text = "";
            btnDelete.Enabled = false;
            btnReset.Enabled = false;
            btnUpdate.Enabled = false;
            btCreate.Enabled = true;
        }

        private void GestionarMetodoDepago_Load(object sender, EventArgs e)
        {
            ListaPagoLoad();
            ResetLoad();
        }

        private void dgvMetodos_SelectionChanged(object sender, EventArgs e)
        {
            PagoSelect = pago.FindbyID(((int)dgvMetodos.CurrentRow.Cells["Id"].Value));

            if(PagoSelect == null)
            {
                MessageBox.Show("Metodo de Pago seleccionado ha sido borrado.");
            }
            else
            {
                btnDelete.Enabled = true;
                btnReset.Enabled = true;
                btnUpdate.Enabled = true;
                btCreate.Enabled = false;
                txtId.Text = PagoSelect.Id.ToString();
                txtNombre.Text = PagoSelect.Nombre.ToString();
            }
        }
    }
}
