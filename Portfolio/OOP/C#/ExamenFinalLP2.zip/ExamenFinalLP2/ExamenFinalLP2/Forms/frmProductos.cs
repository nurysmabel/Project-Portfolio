﻿using ExamenFinalLP2.DataModel.Entities;
using ExamenFinalLP2.DataModel.Interfaces;
using ExamenFinalLP2.DataModel.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExamenFinalLP2
{
    public partial class frmProductos : Form
    {
        IProductoRepository Producto = new ProductoRepository();
        ICategoriaItebisRepository CategoriaItebis = new CategoriaItebisRepository();
        ISuplidorRepository suplidorRepository = new SuplidorRepository();
        Producto ProductoSelect;
        public frmProductos()
        {
            InitializeComponent();
        }

        private void lbItebis_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lbSuplidor_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void ListProductsLoad()
        {
            dbvProductos.DataSource = Producto.GetProductos().Select(x => new 
            { x.Id, x.Nombre, x.Precio, x.SuplidorID, x.CategoriaItebisID, x.Borrado, x.Estatus, x.FechaRegistro, x.FechaModificacion }).ToList();
        }

        private void ResetLoad()
        {
            ListProductsLoad();
            dbvProductos.ClearSelection();
            txtProductoID.Text = "";
            lbItebis.Text = "";
            lbSuplidor.Text = "";
            txtNombre.Text = "";
            btnDelete.Enabled = false;
            btnReset.Enabled = false;
            btnUpdate.Enabled = false;
            btnCreate.Enabled = true;
        }

        private void frmProductos_Load_1(object sender, EventArgs e)
        {
            lbSuplidor.DataSource = suplidorRepository.GetSuplidoresNames().ToList();
            lbItebis.DataSource = CategoriaItebis.GetCategoriasNames().ToList();
            ListProductsLoad();
            ResetLoad();
        }

        private void dbvProductos_SelectionChanged_1(object sender, EventArgs e)
        {
            ProductoSelect = Producto.FindbyID(((int)dbvProductos.CurrentRow.Cells["Id"].Value));

            if (ProductoSelect == null)
            {
                MessageBox.Show("Producto seleccionado ha sido borrado.");
            }
            else
            {

                btnDelete.Enabled = true;
                btnReset.Enabled = true;
                btnUpdate.Enabled = true;
                btnCreate.Enabled = false;
                txtProductoID.Text = ProductoSelect.Id.ToString();
                txtNombre.Text = ProductoSelect.Nombre.ToString();
                nudPrecio.Value = ProductoSelect.Precio;
            }
        }

        private void btnCreate_Click_1(object sender, EventArgs e)
        {
            Producto.Create(new Producto() { Nombre = txtNombre.Text, Precio = nudPrecio.Value, CategoriaItebisID = CategoriaItebis.GetId(lbItebis.SelectedValue.ToString()), SuplidorID = suplidorRepository.GetId(lbSuplidor.SelectedValue.ToString()) , Borrado = false, Estatus = "A", FechaModificacion = DateTime.Now, FechaRegistro = DateTime.Now});
            ListProductsLoad();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            ProductoSelect.Nombre = txtNombre.Text;
            ProductoSelect.Precio = nudPrecio.Value;
            ProductoSelect.SuplidorID = suplidorRepository.GetId(lbSuplidor.SelectedValue.ToString());
            ProductoSelect.CategoriaItebisID = CategoriaItebis.GetId(lbItebis.SelectedValue.ToString());
            ProductoSelect.FechaModificacion = DateTime.Now;
            Producto.Update(ProductoSelect);
            ListProductsLoad();
        }

        private void btnDelete_Click_1(object sender, EventArgs e)
        {
            Producto.Delete(ProductoSelect);
            ListProductsLoad();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetLoad();
        }
    }
}