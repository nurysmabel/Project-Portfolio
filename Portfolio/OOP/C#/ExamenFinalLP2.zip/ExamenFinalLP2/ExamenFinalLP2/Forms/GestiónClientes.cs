﻿using ExamenFinalLP2.DataModel.Entities;
using ExamenFinalLP2.DataModel.Interfaces;
using ExamenFinalLP2.DataModel.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExamenFinalLP2
{
    public partial class GestiónClientes : Form
    {
         IClienteRepository Cliente = new ClienteRepository();
        List<Cliente> clientes;
        public GestiónClientes()
        {
            clientes = Cliente.GetAll(x => x.Facturas).ToList();
            InitializeComponent();
        }

        private void btnCrearFactura_Click(object sender, EventArgs e)
        {
            CrearFactura factura = new CrearFactura((int)dgvClientes.CurrentRow.Cells["Id"].Value);
            factura.ShowDialog();

        }

        private void btnFacturas_Click(object sender, EventArgs e)
        {
            GestionarFacturas GestionarFacturas = new GestionarFacturas((int)dgvClientes.CurrentRow.Cells["Id"].Value);
            GestionarFacturas.ShowDialog();
        }

        private void GestiónClientes_Load(object sender, EventArgs e)
        {
            dgvClientes.DataSource = clientes.Select(p => new { p.Id, p.Nombre, p.Apellido, p.Telefono, p.Correo, p.Direccion, p.Estatus, p.FechaNacimiento, p.FechaRegistro, p.FechaModificacion }).ToList();
            dgvClientes.ClearSelection();
            btnFacturas.Enabled = false;
            btnCrearFactura.Enabled = false;
        }

        private void dgvClientes_SelectionChanged(object sender, EventArgs e)
        {
            btnCrearFactura.Enabled = true;
            btnFacturas.Enabled = true;
        }
    }
}
