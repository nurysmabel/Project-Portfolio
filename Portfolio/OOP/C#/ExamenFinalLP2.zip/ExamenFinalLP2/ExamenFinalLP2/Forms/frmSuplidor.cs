﻿using ExamenFinalLP2.DataModel.Interfaces;
using ExamenFinalLP2.DataModel.Repositories;
using ExamenFinalLP2.DataModel.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExamenFinalLP2
{
    public partial class frmSuplidor : Form
    {
        IProductoRepository Producto = new ProductoRepository();
        ISuplidorRepository Suplidor = new SuplidorRepository();
        Suplidor SuplidorSelect;
        public frmSuplidor()
        {
            InitializeComponent();
        }

        private void btCreate_Click(object sender, EventArgs e)
        {
            try
            {
                Suplidor.Create(new Suplidor() { Nombre = txtNombre.Text, Direccion = txtdireccion.Text, RNC = txtRNC.Text, Borrado = false, Estatus = "A", FechaModificacion = DateTime.Now, FechaRegistro = DateTime.Now });
                ListSuplidorLoad();

                MessageBox.Show("Suplidor creado sastifactoriamente");
            }
            catch (Exception)
            {
                MessageBox.Show("Ha ocurrido un error en la creación del suplidor, puede ser que algún dato esté repetido o vacío");
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                SuplidorSelect.Nombre = txtNombre.Text;
                SuplidorSelect.Direccion = txtdireccion.Text;
                SuplidorSelect.RNC = txtRNC.Text;
                SuplidorSelect.FechaModificacion = DateTime.Now;
                Suplidor.Update(SuplidorSelect);
                ListSuplidorLoad();
            }
            catch (Exception)
            {
                MessageBox.Show("Ha ocurrido un error en la actualización del suplidor, puede ser que algún dato esté repetido o vacío");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Suplidor.Delete(SuplidorSelect);
            ListSuplidorLoad();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetLoad();
        }

        private void ListSuplidorLoad()
        {
            dvbSuplidores.DataSource = Suplidor.GetSuplidores().Select
                (x => new {x.Id , x.Nombre, x.Direccion, x.RNC, x.Borrado, x.Estatus, x.FechaRegistro, x.FechaModificacion } ).ToList();
        }

        private void ResetLoad()
        {
            ListSuplidorLoad();
            dvbSuplidores.ClearSelection();
            txtSuplidorID.Text = "";
            txtNombre.Text = "";
            txtdireccion.Text = "";
            txtRNC.Text = "";
            btnDelete.Enabled = false;
            btnReset.Enabled = false;
            btnUpdate.Enabled = false;
            btnCreate.Enabled = true;
        }

        private void frmSuplidor_Load(object sender, EventArgs e)
        {
            ListSuplidorLoad();
            ResetLoad();
        }

        private void dvbSuplidores_SelectionChanged(object sender, EventArgs e)
        {
            SuplidorSelect = Suplidor.FindbyID(((int)dvbSuplidores.CurrentRow.Cells["Id"].Value));

            if (SuplidorSelect == null)
            {
                MessageBox.Show("Suplidor seleccionado ha sido borrado");
            }
            else
            {

                btnDelete.Enabled = true;
                btnReset.Enabled = true;
                btnUpdate.Enabled = true;
                btnCreate.Enabled = false;
                txtSuplidorID.Text = SuplidorSelect.Id.ToString();
                txtNombre.Text = SuplidorSelect.Nombre.ToString();
                txtdireccion.Text = SuplidorSelect.Direccion.ToString();
                txtRNC.Text = SuplidorSelect.RNC.ToString();
            }
        }
    }
}
