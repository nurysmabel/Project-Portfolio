﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ListsElevator
{
    class Operadores
    {
       /* ascensor elevador = new ascensor();
        public void SumarPeso(float Peso, String Genero)
        {

            if (Genero == "Hombre")
            {
                elevador.PesoActualHombre += Peso;
                elevador.PesoActualTotal += Peso;

                elevador.CantidadPersonaHombre += 1;
                elevador.CantidadPersonaTotal += 1;

            }
            else
            {
                elevador.PesoActualMujer += Peso;
                elevador.PesoActualTotal += Peso;

                elevador.CantidadPersonaMujer += 1;
                elevador.CantidadPersonaTotal += 1;
            }
        }

        public void RestarPeso(float Peso, String Genero)
        {
            if (Genero == "Hombre")
            {
                elevador.PesoActualHombre -= Peso;
                elevador.PesoActualTotal -= Peso;
                elevador.CantidadPersonaHombre -= 1;
                elevador.CantidadPersonaTotal -= 1;
            }
            else
            {
                elevador.PesoActualMujer -= Peso;
                elevador.PesoActualTotal -= Peso;
                elevador.CantidadPersonaMujer -= 1;
                elevador.CantidadPersonaTotal -= 1;
            }
        }
        */
    }
}
