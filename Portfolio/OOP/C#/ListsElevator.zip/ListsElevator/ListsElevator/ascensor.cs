﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ListsElevator
{
    class ascensor
    {
        public float PesoLimite { get; set; }
        public float PesoActualHombre { get; set; }
        public float PesoActualMujer { get; set; }
        public float PesoActualTotal { get; set; }

        public int CantidadPersonaHombre { get; set; }
        public int CantidadPersonaMujer { get; set; }
        public int CantidadPersonaTotal { get; set; }

        public void Ascensor(float PesoActualTotal)
        {
            PesoActualTotal = 0;
        }
        public void RePeroLimite(float PesoLimit)
        {
            PesoLimite = PesoLimit;
        }
        

     

        public float Can_PesoLimite()
        {
            return PesoLimite;
        }

        public float Can_PesoActual()
        {
            return PesoActualTotal;
        }
        public float Can_CantidadHombre()
        {
            return CantidadPersonaHombre;
        }

        public float Can_PesoHombre()
        {
            return PesoActualHombre;
        }
        public float Can_CantidadMujer()
        {
            return CantidadPersonaMujer;
        }

        public float Can_PesoMujer()
        {
            return PesoActualMujer;
        }

        public float Can_TotalCantidad()
        {
            return CantidadPersonaTotal;
        }

        public float Can_TotalPeso()
        {
            return PesoActualTotal;
        }
        public void SumarPeso(float Peso, String Genero)
        {

            if (Genero == "Hombre")
            {
                PesoActualHombre += Peso;
                PesoActualTotal += Peso;

                CantidadPersonaHombre += 1;
                CantidadPersonaTotal += 1;

            }
            else
            {
                PesoActualMujer += Peso;
                PesoActualTotal += Peso;

                CantidadPersonaMujer += 1;
                CantidadPersonaTotal += 1;
            }
        }

        public void RestarPeso(float Peso, String Genero)
        {
            if (Genero == "Hombre")
            {
                PesoActualHombre -= Peso;
                PesoActualTotal -= Peso;
                CantidadPersonaHombre -= 1;
                CantidadPersonaTotal -= 1;
            }
            else
            {
                PesoActualMujer -= Peso;
                PesoActualTotal -= Peso;
                CantidadPersonaMujer -= 1;
                CantidadPersonaTotal -= 1;
            }
        }
    }
}

