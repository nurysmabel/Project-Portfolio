﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;

namespace ListsElevator
{
    class persona
    {
        public List<string> Nombre = new List<string>();
        public List<string> Apellido = new List<string>();
        public String Genero;
        public float Peso;

        }


    }

