﻿using System;
using System.Collections;
using System.Linq;

namespace ListsElevator
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            ascensor elevador = new ascensor();
            //Operadores oper = new Operadores();
            persona person = new persona();


            Console.WriteLine("Elevator Starting...........................\n");
            System.Threading.Thread.Sleep(1000);
            Console.WriteLine("Scale... OK!\n");
            System.Threading.Thread.Sleep(1000);
            Console.WriteLine("Emercengy Protocol... OK!\n");
            System.Threading.Thread.Sleep(1000);
            Console.WriteLine("Systems... OK!\n");
            System.Threading.Thread.Sleep(500);


            Console.WriteLine("Welcome to the Enterprise Elevator\n");
            Console.WriteLine("Please, input elevator's weight limit:");
            elevador.PesoLimite = float.Parse(Console.ReadLine());
            Console.WriteLine("\n");

            Console.WriteLine("Peso Limite: \n" + elevador.PesoLimite);
            System.Threading.Thread.Sleep(1000);
            Console.WriteLine("\n");

            Console.WriteLine("Recieved...");
            Console.WriteLine("\n");
            System.Threading.Thread.Sleep(1000);
            Console.Clear();


            Console.WriteLine("Redirecting...");
            System.Threading.Thread.Sleep(1000);
            Console.Clear();


            //while (elevador.Can_PesoActual() <= elevador.Can_PesoLimite())
            //{
            do
            {
                Console.WriteLine("Input Required Information.\n");
                Console.WriteLine("Input Name:");
                person.Nombre.Add(Console.ReadLine());
                //per.Nombre = Console.ReadLine();
                Console.WriteLine("\n");


                Console.WriteLine("Input person last name:");
                person.Apellido.Add(Console.ReadLine());
                //per.Apellido = Console.ReadLine();
                Console.WriteLine("\n");


                Console.WriteLine("Please person gender H for Hombre, and M for Mujer");
                person.Genero = Console.ReadLine();

                if (person.Genero == "H" || person.Genero == "h")
                {
                    person.Genero = "Hombre";
                }
                else if (person.Genero == "M" || person.Genero == "m")
                {
                    person.Genero = "Mujer";
                }

                Console.WriteLine("\n");


                Console.WriteLine("Input person weight:");
                person.Peso = float.Parse(Console.ReadLine());
                Console.Clear();

                elevador.SumarPeso(person.Peso, person.Genero);

            } while (elevador.Can_PesoActual() <= elevador.Can_PesoLimite());
                
            //}
            
            elevador.RestarPeso(person.Peso, person.Genero);
             person.Nombre.RemoveAt(person.Nombre.Count -1);
             person.Apellido.RemoveAt(person.Apellido.Count -1);
             
            Console.WriteLine("Limit Exceeded...\n");
            System.Threading.Thread.Sleep(1000);

            Console.WriteLine("People On Board:\n");


            Console.WriteLine("Weight Limit:\n" + elevador.PesoLimite);
            Console.WriteLine("\n");

            Console.WriteLine("Person Elevator Total: ");


            Console.WriteLine("Hombres: " + elevador.Can_CantidadHombre());
            Console.WriteLine("Mujeres: " + elevador.Can_CantidadMujer());
            Console.WriteLine("Total: " + elevador.Can_TotalCantidad());
            Console.WriteLine("");


            Console.WriteLine("Weight by Gender: ");
            Console.WriteLine("");
            Console.WriteLine("Hombres: " + elevador.Can_PesoHombre());
            Console.WriteLine("Mujeres: " + elevador.Can_PesoMujer());
            Console.WriteLine("Total: " + elevador.Can_TotalPeso());
            Console.WriteLine("\n");

            foreach(var nombre in person.Nombre.Zip(person.Apellido) )
            {
                
                    Console.WriteLine(i+"."+nombre.ToString());
                    i++;
                
            }

            



            Console.ReadKey();
        }
    }
 }

